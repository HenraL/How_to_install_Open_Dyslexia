# How_to_install_Open_Dyslexia
 This rep contains a webpage I've created to help and guide people in the installation of the fonts Open Dyslexia for dyslexic people. This Webpage also gives you a few types and advices on what to and not use when writing text for dyslexic people.
